###################################################
# MÉTODO DE GAUSS NEWTON PARA QUADRADOS MÍNIMOS NÃO LINEARES
# Veja
#   leonardosecchin.github.io/files/otim2/6.5.Quad_min_naolinear_Gauss_Newton.pdf
#
# Entrada:
#   nls  : modelo NLSModels
#   x0   : ponto inicial (opcional)
#   eps  : tolerancia para norma do gradiente (opcional, padrão 1e-6)
#   maxit: número máximo de iterações (opcional, padrão 1000)
#
# Autor: Leonardo D. Secchin
# Data : 18/03/2022
###################################################

using NLPModels, LinearAlgebra, Printf, SparseArrays

# FUNÇÃO PRINCIPAL
function gaussnewton(nls; x0=nothing, eps=1e-6, maxit=1000)

    # número de variáveis
    n = nls.nls_meta.nvar

    # número de equações
    m = nls.nls_meta.nequ

    # ponto inicial
    if x0 == nothing
        # se o usuário não forneceu x0, busca em nls
        x0 = nls.nls_meta.x0

        if (x0 == nothing) || (isempty(x0))
            # se não há x0 em nls, toma a origem
            x0 = zeros(n)
        end
    end

    x0     = float(x0)
    x      = x0
    iter   = 0

    # R(x)
    R = residual(nls, x)

    # gradiente de f = 1/2|R|^2, isto é, g = J^T R
    g = jtprod_residual(nls, x, R)

    # |g|_inf
    gsupn = norm(g, Inf)

    # imprimi informações do problema
    println("============================")
    println("        GAUSS-NEWTON")
    println()
    println("Problema  : ", nls.meta.name)
    println("Variáveis : ", n)
    println("Equações  : ", m)
    println()
    println("eps       : ", eps)
    println("============================\n")

    # imprimir informações do ponto inicial
    @printf("iter %4d:    |g| = %8.2e,    |R| = %8.2e\n", 0, gsupn, norm(R, Inf))

    # loop principal
    while (iter <= maxit) && (gsupn > eps)

        # calcula direção d
        J = jac_residual(nls, x)

        # resolve o problema de quadrados mínimos linear 1/2|J*d + R|^2,
        # cuja equação normal é J^T J d = -J^T R, com rotinas
        # internas do Julia (veja documentação executando ?\)
        d = \( J , -R )     # *** ajuste para Levenberg-Marquardt ***

        # atualiza iterando
        x = x + d

        # prepara a próxima iteração

        # R(x)
        R = residual(nls, x)

        # gradiente de f = 1/2|R|^2, isto é, g = J^T R
        g = jtprod_residual(nls, x, R)

        # |g|_inf
        gsupn = norm(g, Inf)

        # *** atualize lambda para Levenberg-Marquardt ***

        # incrementa contador
        iter += 1

        # imprimi informações da iteração
        @printf("iter %4d:    |g| = %8.2e,    |R| = %8.2e\n", iter, gsupn, norm(R, Inf))

    end

    # imprimi informações finais
    println("\n============================")
    if gsupn <= eps
        println("Solução encontrada!")
        println()
        @printf("Norma do resíduo final (|R|_inf) = %8.2e\n", norm(R, Inf))
        if n <= 10
            println()
            println("Solução: ",Vector(x))
        end
    else
        println("Resolução falhou.")
    end
    println("============================")

    return
end