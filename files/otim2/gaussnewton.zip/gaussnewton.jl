###################################################
# MÉTODO DE GAUSS-NEWTON PARA QUADRADOS MÍNIMOS NÃO LINEAR
# Veja
#   leonardosecchin.github.io/files/otim2/6.5.Quad_min_naolinear_Gauss_Newton.pdf
#
# Entrada:
#   nls   : modelo NLSModels
#   x0    : ponto inicial (opcional)
#   tol   : tolerância para norma do gradiente (opcional, padrão 1e-8)
#   eta   : parâmetro da busca linear de Armijo (opcional, padrão 1e-4)
#   maxit : número máximo de iterações (opcional, padrão 1000)
#   saidas: imprimi mensagens na tela? (padrão true)
#
# Autor: Leonardo D. Secchin
# Data : 18/03/2022, atualizado em 20/11/26
###################################################

using NLPModels, LinearAlgebra, Printf, SparseArrays

# FUNÇÃO PRINCIPAL
function gaussnewton(
    nls;
    x0 = [],
    tol = 1e-8,
    eta = 1e-4,
    maxit = 1000,
    saidas = true
)
    # número de variáveis
    n = nls.nls_meta.nvar

    # número de equações
    m = nls.nls_meta.nequ

    # ponto inicial
    if !isempty(x0)
        x = Float64.(x0)
    else
        # se o usuário não forneceu x0, busca em nls
        if !isempty(nls.nls_meta.x0)
            x = deepcopy(nls.nls_meta.x0)
        else
            # se não há x0 em nls, toma a origem
            x = zeros(n)
        end
    end

    # define objetos
    iter = 0
    R = residual(nls, x)                # R(x)
    t = 1.0                             # passo busca linear
    xnew = Vector{Float64}(undef, n)    # aloca novo ponto para busca linear
    ∇f = Vector{Float64}(undef, n)      # aloca ∇f = 1/2|R|^2 = J^T R
    tmin = 0.5 * eps()                  # passo mínimo busca linear

    # imprimi informações do problema
    if saidas
        println("="^34)
        println("    GAUSS-NEWTON")
        println()
        println("Problema    : ", nls.meta.name)
        println("Variáveis   : ", n)
        println("Equações    : ", m)
        println()
        println("Tol. parada : ", tol)
        println("="^34)
        println()
        println("  it    |∇f|_∞     |R|_∞         t")
        println("-"^34)
    end

    # loop principal
    while (true)
        # calcula ∇f = 1/2|R|^2 = J^T R
        jtprod_residual!(nls, x, R, ∇f)

        # normas de ∇f e R
        ∇fsupn = norm(∇f, Inf)
        Rsupn = norm(R, Inf)

        # imprime informações do iterando
        if saidas
            @printf("%4d  %8.2e  %8.2e  %8.2e\n", iter, ∇fsupn, Rsupn, t)
        end

        ##############
        # TESTES DE PARADA
        ##############
        if (∇fsupn <= tol) || (Rsupn <= tol)
            if saidas
                println("\nSolução encontrada!")
            end
            break
        end
        if iter > maxit
            if saidas
                println("\nFALHA: Número máximo de iterações atingido.")
            end
            break
        end
        if t < tmin
            if saidas
                println("\nFALHA: Passo muito pequeno.")
            end
            break
        end

        ##############
        # DIREÇÃO
        ##############
        J = jac_residual(nls, x)

        # resolve o problema de quadrados mínimos linear 1/2|J*d + R|^2,
        # cuja equação normal é J^T J d = -J^T R, com rotinas
        # internas do Julia (veja documentação executando ?\)
        d = []
        try
            d = \( J , -R )
        catch
            println("\nFALHA: Jacobiana com posto incompleto, Gauss-Newton não pode continuar.")
            break
        end

        ##############
        # BUSCA LINEAR
        ##############
        # f = 1/2 |R|^2 no ponto corrente. Neste ponto R(x) está atualizado
        f = 0.5 * dot(R,R)

        ∇ftd = dot(∇f,d)

        # passo inicial e ponto correspondente
        t = 1.0
        @. xnew = x + d

        # f no novo ponto
        residual!(nls, xnew, R)
        fnew = 0.5 * dot(R,R)

        # Armijo + interpolação quadrática com salvaguardas
        while (fnew > f + t*eta*∇ftd) && (t >= tmin)
            # passo da interpolação quadrática
            tquad = - 0.5*∇ftd*(t^2) / (fnew - f - t*∇ftd)

            # salvaguardas
            if (tquad < 0.1*t) || (tquad > 0.9*t)
                # backtracking
                t = 0.5 * t
            else
                # aceita o passo da interpolação quadrática
                t = tquad
            end

            # novo ponto
            @. xnew = x + t*d
            residual!(nls, xnew, R)
            fnew = 0.5 * dot(R,R)
        end

        # atualiza iterando
        @. x = xnew

        # incrementa contador
        iter += 1
    end

    return x
end
