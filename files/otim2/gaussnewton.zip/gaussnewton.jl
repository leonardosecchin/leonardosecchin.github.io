###################################################
# MÉTODO DE GAUSS NEWTON PARA QUADRADOS MÍNIMOS NÃO LINEARES
# Veja
#   leonardosecchin.github.io/files/otim2/6.5.Quad_min_naolinear_Gauss_Newton.pdf
#
# Entrada:
#   nls  : modelo NLSModels
#   x0   : ponto inicial (opcional)
#   eps  : tolerancia para norma do gradiente (opcional, padrão 1e-6)
#   maxit: número máximo de iterações (opcional, padrão 1000)
#
# Autor: Leonardo D. Secchin
# Data : 18/03/2022
###################################################

using NLPModels, LinearAlgebra, Printf, SparseArrays

# FUNÇÃO PRINCIPAL
function gaussnewton(nls; x0=nothing, eps=1e-6, maxit=1000)

    # número de variáveis
    n = nls.nls_meta.nvar

    # número de equações
    m = nls.nls_meta.nequ

    # ponto inicial
    if x0 == nothing
        # se o usuário não forneceu x0, busca em nls
        x0 = nls.nls_meta.x0

        if (x0 == nothing) || (isempty(x0))
            # se não há x0 em nls, toma a origem
            x0 = zeros(n)
        end
    end

    x0     = float(x0)
    status = 1
    x      = x0
    iter   = 0

    R = []

    println("============================")
    println("        GAUSS-NEWTON")
    println()
    println("Problema  : ", nls.meta.name)
    println("Variáveis : ", n)
    println("Equações  : ", m)
    println()
    println("eps       : ", eps)
    println("============================\n")

    # loop principal
    while (iter <= maxit)

        # calcula R(x)
        R = residual(nls, x)

        # calcula gradiente de f = 1/2|R|^2, isto é g = J^T R
        g = jtprod_residual(nls, x, R)

        # |g|_inf
        gsupn = norm(g, Inf)

        # imprimi informações da iteração
        @printf("iter %4d:    |g| = %8.2e,    |R| = %8.2e\n",iter, gsupn, norm(R, Inf))

        # criterio de parada
        if gsupn <= eps
            # sucesso!
            status = 0

            break
        end

        # calcula direção d
        J = jac_residual(nls, x)

        # resolve o problema de quadrados mínimos linear 1/2|J*d + R|^2,
        # cuja equação normal é J^T J d = -J^T R, com rotinas
        # internas do Julia (veja documentação executando ?\)
        d = \(J,-R)

        # atualiza iterando
        x = x + d

        # finaliza iteração
        iter += 1

    end

    # imprimi informações finais
    println("\n============================")
    if status == 0
        println("Solução encontrada!")
        println()
        @printf("Norma do resíduo final (|R|_inf) = %8.2e\n", norm(R, Inf))
        if n <= 10
            println()
            println("Solução: ",x)
        end
    else
        println("Resolução falhou.")
    end
    println("============================")

    return
end