using JuMP, NLPModels, NLPModelsJuMP

############## EXEMPLO ###############
# Resolver o sistema abaixo com Gauss-Newton:
#
# R(x) = [    x1 - 1     ] = [ 0 ]
#        [ 10(x2 - x1^2) ]   [ 0 ]
#
# (o lado direito sempre será zero)
# Para documentação do NLSModels, consulte
# https://juliasmoothoptimizers.github.io/NLPModels.jl/latest/api/#nls-api
######################################


# CONSTRUINDO O SISTEMA

# iniciando o modelo JuMP
Q = Model()

# inserindo as variáveis x1 e x2
@variable(Q, x[1:2])

# inserindo as equações. Elas são definidas como "expressões
# não lineares (NLexpression)" no modelo JuMP, e cada uma recebe um nome,
# que aqui serão R1 e R2.
@NLexpression(Q, R1, x[1] - 1.0)
@NLexpression(Q, R2, 10*x[2] - 10*x[1]^2)

# convertendo o sistema JuMP R(x)=0 para NLSModels
nls = MathOptNLSModel(Q, [R1 R2])


# APLICANDO GAUSS-NEWTON

include("gaussnewton.jl")

gaussnewton(nls)