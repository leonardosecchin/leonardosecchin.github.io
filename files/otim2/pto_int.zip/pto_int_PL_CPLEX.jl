###################################################
# USO DOS PONTOS INTERIORES DO CPLEX PARA PL

# Autor: Leonardo D. Secchin
###################################################

# pacotes para manipulação matricial
using LinearAlgebra, SparseArrays

using CPLEX, JuMP


####################################
# PONTOS INTERIORES DO CPLEX
####################################

function cplex(A, b, c; lb=[], ub=[], eps=1e-8, saidas=true, simplex=false, presolve=true)

    # Lê dimensões
    m,n = size(A)

    # Verifica se as dimensões dos dados são compatíveis
    if (length(b) != m) | (length(c) != n) | (m > n)
        error("Dados com dimensões incompatíveis!")
    end

    # limitantes padrão das variáveis, caso não fornecidos
    if isempty(lb)
        lb = zeros(n,1)
    end
    if isempty(ub)
        ub = Inf * ones(n,1)
    end

    # estrutura JuMP associada com CPLEX
    P = Model(CPLEX.Optimizer)

    ### configura CPLEX (ver https://www.ibm.com/docs/en/icos/20.1.0?topic=cplex-list-parameters)

    # desliga presolve
    if !presolve
        set_optimizer_attribute(P, "CPXPARAM_Preprocessing_Presolve", CPX_OFF)
        set_optimizer_attribute(P, "CPX_PARAM_DEPIND", 0)
    end

    # saídas na tela
    if !saidas
        set_optimizer_attribute(P, "CPXPARAM_ScreenOutput", 0)
    end

    if simplex
        # escolhe o simplex primal
        set_optimizer_attribute(P, "CPXPARAM_LPMethod", CPX_ALG_PRIMAL)
    else
        # escolhe o algoritmo de barreiras (pontos interiores) do CPLEX
        set_optimizer_attribute(P, "CPXPARAM_LPMethod", CPX_ALG_BARRIER)

        # desliga crossover para Simplex (não purifica a solução para uma solução básica)
        set_optimizer_attribute(P, "CPXPARAM_SolutionType", CPX_NONBASIC_SOLN)

        # eps para convergência (o padrão já é 1e-8)
        set_optimizer_attribute(P, "CPXPARAM_Barrier_ConvergeTol", eps)
    end

    # adiciona variáveis
    @variable(P, x[1:n])

    # define limitantes das variáveis
    for j in 1:n
        if lb[j] > -1e+308
            set_lower_bound(x[j], lb[j])
        end
        if ub[j] < 1e+308
            set_upper_bound(x[j], ub[j])
        end
    end

    # adiciona função objetivo
    @objective(P, Min, sum(c[j]*x[j] for j in 1:n))

    # adiciona restrições
    for i in 1:m
        @constraint(P, sum(A[i,j]*x[j] for j in 1:n) == b[i])
    end

    # resolve P
    T = @elapsed optimize!(P)

    # retorna solução
    return value.(x),objective_value(P), max(simplex_iterations(P),barrier_iterations(P)), ((termination_status(P)) == OPTIMAL ? 0 : 1), T
end
