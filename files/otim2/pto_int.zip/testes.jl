# pacotes para manipulação matricial
using LinearAlgebra, SparseArrays

# pacotes impressão e gravação de resultados
using Printf, DataFrames

# pacote para download de matrizes de https://sparse.tamu.edu
using MatrixDepot

using JLD2, BenchmarkProfiles, Plots

include("pto_int_PL.jl")
include("pto_int_PL_CPLEX.jl")

# Função para testes com problemas da NETLIB
# http://www.netlib.org/lp/data/index.html
function testar(; saidas=false)

    # PARAMETROS SUGERIDOS
    maxit = 100
    eps   = 1e-8
    tau   = 0.99995
    epsz  = 30

    # Problemas na forma padrão selecionados da NETLIB
    #   Fonte dos arquivos: grupo "LPnetlib" - https://sparse.tamu.edu/LPnetlib
    netlib = [
        "LPnetlib/lp_adlittle",
        "LPnetlib/lp_afiro",
        "LPnetlib/lp_agg",
        "LPnetlib/lp_agg2",
        "LPnetlib/lp_agg3",
        "LPnetlib/lp_bandm",
        "LPnetlib/lp_beaconfd",
        "LPnetlib/lp_blend",
        "LPnetlib/lp_bnl2",
        "LPnetlib/lp_d2q06c",
        "LPnetlib/lp_e226",
        "LPnetlib/lp_fffff800",
        "LPnetlib/lp_osa_60",
        "LPnetlib/lp_israel",
        "LPnetlib/lp_lotfi",
        "LPnetlib/lp_maros_r7",
        "LPnetlib/lp_osa_07",
        "LPnetlib/lp_osa_14",
        "LPnetlib/lp_osa_30",
        "LPnetlib/lp_sc50a",
        "LPnetlib/lp_sc105",
        "LPnetlib/lp_sc205",
        "LPnetlib/lp_sc50b",
        "LPnetlib/lp_scagr25",
        "LPnetlib/lp_scagr7",
        "LPnetlib/lp_scfxm1",
        "LPnetlib/lp_scfxm2",
        "LPnetlib/lp_scfxm3",
        "LPnetlib/lp_scrs8",
        "LPnetlib/lp_scsd1",
        "LPnetlib/lp_scsd6",
        "LPnetlib/lp_scsd8",
        "LPnetlib/lp_sctap1",
        "LPnetlib/lp_sctap2",
        "LPnetlib/lp_sctap3",
        "LPnetlib/lp_share1b",
        "LPnetlib/lp_share2b",
        "LPnetlib/lp_woodw",
        "LPnetlib/lp_stocfor1",
        "LPnetlib/lp_stocfor2",
        "LPnetlib/lp_stocfor3",
        "LPnetlib/lp_truss",
        "LPnetlib/lpi_itest6",
        "LPnetlib/lpi_bgindy",
        "LPnetlib/lpi_bgprtr",
        "LPnetlib/lpi_itest2",
        "LPnetlib/lpi_klein1",
        "LPnetlib/lpi_klein2",
        "LPnetlib/lpi_klein3"
    ];

    # cabeçalho tabela com resultados
    resultados = DataFrame(Prob=[],n=[],m=[],st=[],it=[],f=[],viab=[],KKT=[],tempo=[],metodo=[])

    # executa pontos interiores em cada problema
    for p in netlib

        # lê problema (e baixa caso não tenha sido baixado)
        PL = mdopen(p);
        nomeprob = p[10:end]

        # PL é uma estutura com as seguintes propriedades:
        # PL.A, PL.b : sistema Ax=b
        # PL.c       : coeficiente função objetivo
        # PL.n, PL,m : número de variáveis e restrições
        # PL.nnz     : número de não zeros em A

        PLstatus = -1
        PLiter   = -1
        PLviab   = -1
        PLKKT    = -1
        PLf      = NaN
        PLtempo  = -1

        try
            println("Prob: "*p)

            # aplica pontos interiores com reordenamento AMD
            PLtempo = @elapsed ~, PLf, PLiter, PLviab, PLKKT, PLstatus =
                seguidor(PL.A, PL.b, PL.c, maxit=maxit, eps=eps, tau=tau, epsz=epsz, saidas=saidas);

            push!(resultados, (nomeprob, PL.n, PL.m, PLstatus, PLiter, PLf, PLviab, PLKKT, PLtempo, "seguidor"))

            # aplica pontos interiores do CPLEX
            ~, PLf, PLiter, PLstatus, PLtempo =
                cplex(PL.A, PL.b, PL.c, eps=eps, saidas=saidas);

            push!(resultados, (nomeprob, PL.n, PL.m, PLstatus, PLiter, PLf, NaN, NaN, PLtempo, "cplex"))

            # aplica pontos interiores do CPLEX sem presolve
            ~, PLf, PLiter, PLstatus, PLtempo =
                cplex(PL.A, PL.b, PL.c, eps=eps, saidas=saidas, presolve=false);

            push!(resultados, (nomeprob, PL.n, PL.m, PLstatus, PLiter, PLf, NaN, NaN, PLtempo, "cplex s/ presolve"))

        catch
            println("ERRO ao resolver $(nomeprob)!")
        end

    end

    # ordena resultados por nome do problema (coluna 1)
    sort!(resultados, [1,10])

    @save "resultados.jld2" resultados

    # salva resultados em TXT
    txt = open("resultados.txt", "w")
    write(txt, @sprintf("%s", resultados))
    close(txt)

    # Você pode salvar o resultado em planilhas.
    # Veja https://leonardosecchin.github.io/juliaopt_ex11/
end
