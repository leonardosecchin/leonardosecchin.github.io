###############################
# Localização de facilidades (exemplo dado em aula)
###############################

# Autor: Leonardo D. Secchin
# Abril, 2024

using JuMP
using GLPK
using Printf

# número de clientes
m = 6

# número de localizações para as facilidades
n = 5

# custos de instalação de uma facilidade em cada localização
f = [2;4;5;3;3]

# custos de alocação cliente x facilidade
c = [6  2  1  3  5;
    4  10  2  6  1;
    3  2  4  1  3;
    2  0  4  1  4;
    1  8  6  2  5;
    3  2  4  8  1]

# cria modelo
P = Model(GLPK.Optimizer)

# mensagens padrão na tela
set_optimizer_attribute(P, "msg_lev", GLPK.GLP_MSG_ON)

# insere variáveis
@variable(P, x[1:m,1:n] >= 0)
@variable(P, y[1:n], Bin)

# função objetivo
@objective(P, Min, sum(c[i,j]*x[i,j] for i in 1:m, j in 1:n) + sum(f[j]*y[j] for j in 1:n))

# restrições
for i in 1:m
    @constraint(P, sum(x[i,j] for j in 1:n) == 1)
end

for i in 1:m, j in 1:n
    @constraint(P, x[i,j] <= y[j])
end

# resolve P
optimize!(P)

# imprimi informações da solução
println()
println("====================================")
println("Quantidade de unidades instaladas: ", Int(sum(value.(y))))
println("Unidades instaladas: ", Int.(value.(y)))
println()
print("Facilidade  ")
for i=1:n
    @printf("%3d  ",i)
end
println()
print("Instalada?")
for i=1:n
    if value.(y[i]) > 0.5
        print("    X")
    else
        print("     ")
    end
end
println()
for i=1:m
    print("Cliente ",i,":  ")
    for j=1:n
        @printf("%.1lf  ",abs(value.(x[i,j])))
    end
    println()
end
println()
println("Custo total: ", objective_value(P))
println("====================================")
