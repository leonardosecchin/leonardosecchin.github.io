###############################
# Problema do caminho mínimo (código que lê problemas da coletânea TSPLIB)
###############################

# Autor: Leonardo D. Secchin
# Abril, 2024

# Referência: seção 2.1 de
# ARAUJO, S. A. de; RANGEL, S. Matemática Aplicada ao Planejamento da Produção e Logı́stica. Notas em Matemática Aplicada, v. 76. SBMAC, 2014

# EXEMPLOS:
# julia> include("menor_caminho.jl")
# julia> menor_caminho(:berlin52, 1, 52)
# julia> menor_caminho(:berlin52, 1, 52, percdist=0.03)  # considera 3% de distâncias entre cidades
#
# Uma lista dos problemas que podem ser testados encontra-se no arquivo "instancias_EUC_2D.txt"

using JuMP, GLPK
using TSPLIB
using Plots
using SparseArrays, LinearAlgebra

# função que resolve um problema dado
function caminho_minimo(problema::Symbol, origem::Int, destino::Int; percdist=0.04)
    # lê dados do problema
    prob = readTSPLIB(problema)

    # número de cidades
    n = prob.dimension

    # distância entre TODAS as cidades
    c = prob.weights

    # escolhe percdist % das distâncias
    S = sprand(Bool, n, n, percdist)

    # elimina distâncias em c
    c[.!S] .= 0.0

    # ajusta c
    c = Symmetric(c,:U)

    # testa se origem e destino são válidas
    if (min(origem,destino) < 1) || (max(origem,destino) > n)
        println("As cidades de origem e destino estão incorretas. Elas devem estar entre 1 e ",n)
        return
    end

    P = Model(GLPK.Optimizer)

    # configurações do resolvedor
    set_optimizer_attribute(P, "msg_lev", GLPK.GLP_MSG_ON)
    set_optimizer_attribute(P, "presolve", GLPK.GLP_ON)

    # adiciona variáveis
    @variable(P, x[1:n,1:n], Bin)

    # função objetivo
    @objective(P, Min, sum(c[i,j]*x[i,j] for i=1:n, j=1:n))

    # sai da cidade de origem
    @constraint(P, sum(x[origem,j] for j=1:n) == 1)

    # chega à cidade de destino
    @constraint(P, sum(x[i,destino] for i=1:n) == 1)

    # passa por cidades no caminho, excluindo origem e destino
    for i=1:n
        if (i != origem) && (i != destino)
            @constraint(P, sum(x[i,j] for j=1:n) - sum(x[k,i] for k=1:n) == 0)
        end
    end

    # Restrições adicionais: ajuste à grafos incompletos e não direcionados
    # zera x[i,j] com custos nulos (caminho direto entre i e j não existe)
    for i=1:n, j=1:n
        if c[i,j] == 0.0
            @constraint(P, x[i,j] == 0)
        end
    end
    # elimina a possibilidade de voltar à origem
    @constraint(P, sum(x[j,origem] for j=1:n) == 0)
    # elimina a possibilidade de criação de ciclo com o destino
    @constraint(P, sum(x[destino,j] for j=1:n) == 0)

    # resolve modelo
    optimize!(P)

    println("Otimização completa!")

    k = origem
    sol = [k]
    println()
    print(k)

    if (termination_status(P) == OPTIMAL)
        # o problema foi resolvido, constrói o menor caminho (solução) a partir dos valores de x
        xx = Bool.(value.(x) .> 0.5)

        while (k != destino)
            # próxima cidade
            for i=1:n
                if (xx[k,i] == true) || (xx[i,k] == true)
                    xx[k,i] = false
                    xx[i,k] = false
                    k = i
                    break
                end
            end
            print(" -> "); print(k)
            push!(sol,k)
        end

        println()

        # plota solucao
        plota_solucao(prob, c, sol)
    else
        println()
        println("Não existe caminho entre as cidades escolhidas!")
    end
end


# função para plotar (fazer uma figura) da solução
function plota_solucao(prob, c, sol)
    # número de cidades
    n = prob.dimension

    # tamanho da imagem
    xmin = minimum(prob.nodes[:,1])
    xmax = maximum(prob.nodes[:,1])
    ymin = minimum(prob.nodes[:,2])
    ymax = maximum(prob.nodes[:,2])

    # adiciona 5% de folga nas lateriais
    folga = 0.05*max( xmax-xmin, ymax-ymin )

    fig = plot(title=prob.name, xlims=(xmin-folga,xmax+folga), ylims=(ymin-folga,ymax+folga), aspect_ratio=:equal, leg=false)

    # plota todos os seguimentos considerados
    for i = 1:n, j=1:n
        if c[i,j] > 0.0
            fig = plot!([prob.nodes[i,1], prob.nodes[j,1]], [prob.nodes[i,2], prob.nodes[j,2]], color="gray", lw=0.2)
        end
    end

    # plota cidades
    for i = 1:n
        fig = scatter!([prob.nodes[i,1]], [prob.nodes[i,2]], color="white", mark=:o, markersize=6)
        fig = annotate!([prob.nodes[i,1]], [prob.nodes[i,2]], text(i, :blue, :center, 4))
    end

    # plota solução
    for i = 1:(length(sol)-1)
        fig = plot!( [prob.nodes[sol[i],1], prob.nodes[sol[i+1],1]], [prob.nodes[sol[i],2], prob.nodes[sol[i+1],2]], color="red", lw=1)
    end

    # mostra figura
    display(fig)
end
