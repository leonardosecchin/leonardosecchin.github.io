###############################
# Planejamento da produção
###############################

# Autor: Leonardo D. Secchin
# Abril, 2024

# Referência: exemplo da seção 4.1 de
# RANGEL, S. Introdução à Construção de Modelos de Otimização Linear e Inteira. Notas em Matemática Aplicada, v. 18. SBMAC, 2012

using JuMP, GLPK

P = Model(GLPK.Optimizer)

set_optimizer_attribute(P, "msg_lev", GLPK.GLP_MSG_ALL)

@variable(P, madeira >= 5)

@variable(P, compensado >= 12)

@objective(P, Max, 45*madeira + 60*compensado)

@constraint(P, madeira + 2*compensado <= 32)

@constraint(P, 4*madeira + 4*compensado <= 72)

optimize!(P)

println("Quantidade de madeira: ", value(madeira))

println("Quantidade de compensado: ", value(compensado))

println("Lucro: ", objective_value(P))
