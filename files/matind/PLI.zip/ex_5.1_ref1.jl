###############################
# Problema da mochila
###############################

# Autor: Leonardo D. Secchin
# Abril, 2024

# Referência: exemplo da seção 5.1 de
# RANGEL, S. Introdução à Construção de Modelos de Otimização Linear e Inteira. Notas em Matemática Aplicada, v. 18. SBMAC, 2012

using JuMP, GLPK

P = Model(GLPK.Optimizer)

set_optimizer_attribute(P, "msg_lev", GLPK.GLP_MSG_ALL)

@variable(P, x[1:3], Bin)

@objective(P, Max, 40*x[1] + 10*x[2] + 10*x[3])

@constraint(P, 3*x[1] + 5*x[2] + 4*x[3] <= 10)

optimize!(P)

println()
println("============================")
println("Solução: ", value.(x))
println("Retorno esperado: ", objective_value(P))
println("============================")
