###############################
# Problema da mochila (código para mudar dados do problema)/
###############################

# Autor: Leonardo D. Secchin
# Abril, 2024

# Referência:
# RANGEL, S. Introdução à Construção de Modelos de Otimização Linear e Inteira. Notas em Matemática Aplicada, v. 18. SBMAC, 2012

using JuMP, GLPK

###############################
# DADOS DO PROBLEMA (pode mudar)
# número de itens
n = 10

# pesos
a = [1; 2; 5; 6; 9; 2; 3; 6; 2; 4]

# ganhos
p = [3; 6; 5; 2; 6; 9; 8; 5; 1; 2]

# capacidade
C = 11
###############################

# cria modelo
P = Model(GLPK.Optimizer)

# mensagens padrão na tela
set_optimizer_attribute(P, "msg_lev", GLPK.GLP_MSG_ALL)

# variáveis
@variable(P, x[1:n], Bin)

# função objetivo
@objective(P, Max, sum(p[j]*x[j] for j=1:n))

# restrição de capacidade
@constraint(P, sum(a[j]*x[j] for j=1:n) <= C)

# resolve P
optimize!(P)

# imprimi informações da solução
println()
println("============================")
println("Num itens:   ", n)
println("Ganhos:      ", p)
println("Pesos:       ", a)
println("Peso máximo: ", C)
println()
println("Solução:     ", Int.(value.(x)))
println("Peso total:  ", sum(a[j]*value(x[j]) for j=1:n))
println("Ganho total: ", objective_value(P))
println("============================")
