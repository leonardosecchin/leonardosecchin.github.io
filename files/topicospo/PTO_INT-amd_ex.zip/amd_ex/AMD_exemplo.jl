###################################################
# Exemplo da diferença entre usar ou não AMD
# antes de Cholesky.
#
# Autor: Leonardo D. Secchin
# Data : 21/06/2021
###################################################

using LinearAlgebra, SparseArrays, MatrixMarket, UnicodePlots

imprimeG = true

# carrega a matrix plat362.mtx
# (fonte: https://sparse.tamu.edu/HB/plat362, formato "Matrix Market")
M = MatrixMarket.mmread("plat362.mtx");

# ordem de M
n = size(M)[1];

# COMANDO cholesky DO PACOTE LinearAlgebra
# ----------------------------------------
# O parâmetro perm indica qual permutação usar para reordenar a matriz.
# Quando perm=nothing, cholesky aplica AMD automaticamente.
# Quando perm=1:n, não aplica ordenação. Ou seja, P = Id.

println("=========================================")
println("CHOLESKY SEM REORDENAMENTO (P=Id):")
println("=========================================")

tC = @elapsed C = cholesky(Symmetric(M), check=true, perm=1:n);
# Captura o fator de Cholesky G. Julia sempre retorna G triangular inferior.
# Portanto temos GG' = P'MP.
G = sparse(C.L);

println("Dados da fatoração:")
println("Tempo: $tC segundos")
println(C)

if imprimeG
    println("Fator Cholesky sem reordenamento:")
    println(spy(G))
end


println("=========================================")
println("CHOLESKY DEPOIS DE REORDENAMENTO COM AMD:")
println("=========================================")

tC_amd = @elapsed C_amd = cholesky(Symmetric(M), check=true, perm=nothing);
G_amd = sparse(C_amd.L);

println("Dados da fatoração:")
println("Tempo: $tC_amd segundos")
println(C_amd)

if imprimeG
    println("Fator Cholesky depois de AMD:")
    println(spy(G_amd))
end
