###################################################
# Geração de colunas simples para Cutting Stock (relaxação)
#
# Autor: Leonardo D. Secchin
# Data : 27/09/2021
# leonardosecchin.github.io/topicospo/
###################################################

using JuMP, LinearAlgebra, CPLEX, DelimitedFiles, Printf


# Leitura de instâncias (http://or.dei.unibo.it/library/bpplib)
# FORMATO:
#   ​​Number of item types (m)
#   Capacity of the bins (W)
#   For each item type j (j = 1,...,m):
#   Weight (wj) and demand (dj)
function ler(arquivo)
    dados = readdlm(arquivo)

    m = Int(dados[1,1])
    W = Int(dados[2,1])
    w = Float64.(dados[3:end,1])
    d = Float64.(dados[3:end,2])

    return m, W, w, d
end


####################################
# FUNÇÃO PRINCIPAL - GERAÇÃO COLUNAS
####################################
function gercol(arquivo; saidas=true)

    # lê instância
    m, W, w, d = ler(arquivo)

    if saidas
        println("\n===================================")
        println("Dados do problema:")
        println("Diferentes comprimentos dos pedaços (m) = ",m)
        println("Comprimento bobina (W) = ",W)
        println("===================================")
    end

    # número de colunas adicionadas
    varadd = 0

    # FO problema mestre
    FOmestre = -Inf

    # tolerância para declarar máximo custo reduzido <= 0 (base ótima)
    epsmaxcustoreduzido = 1e-8


    # INSTÂNCIA PROBLEMA MESTRE

    mestre = Model(CPLEX.Optimizer)
    set_silent(mestre)

    # INSTÂNCIA PROBLEMA AUXILIAR
    auxiliar = Model(CPLEX.Optimizer)
    set_silent(auxiliar)

    @variable(auxiliar, 0 <= a[1:m], Int)
    @constraint(auxiliar, sum(w[i]*a[i] for i in 1:m) <= W)


    # PROBLEMA MESTRE INICIAL

    # número de colunas no problema mestre inicial
    ncols = m

    # conjunto de variáveis iniciais x[1],...,x[ncols]
    J0 = 1:ncols

    # perfis iniciais (colunas iniciais)
    A = I(m)

    @variable(mestre, 0 <= x[J0])

    @objective(mestre, Min, sum(x[j] for j in J0))

    # Insere restrições. consRef[i] indicará a i-ésima restrição
    @constraint(mestre, consRef[i=1:m], sum(A[i,j]*x[j] for j in J0) == d[i])

    while true

        # resolve problema mestre atual
        optimize!(mestre)

        # se não resolveu problema mestre, retorna erro
        if termination_status(mestre) != MOI.OPTIMAL
            @error("Problema mestre não resolvido ($ncols colunas)")
            return nothing, nothing, FOmestre, varadd
        end

        FOmestre = objective_value(mestre)

        # captura variáveis duais do problema mestre (multiplicadores das restrições)
        # para construção da FO do problema auxiliar
        if !has_duals(mestre)
            @error("Variáveis duais não disponíveis!")
            return nothing, nothing, FOmestre, varadd
        end

        u = dual.(consRef)


        # AJUSTA FO E RESOLVE PROBLEMA AUXILIAR

        @objective(auxiliar, Max, sum(u[i]*a[i] for i in 1:m) - 1.0)

        optimize!(auxiliar)

        # Custo reduzido máximo
        maxcustoreduzido = objective_value(auxiliar)

        if saidas
            if mod(varadd,20) == 0
                println("\n  it  | FO mestre | custo reduzido máx")
            end
            @printf("%5d | %8.3e | %8.3e\n", varadd, FOmestre, maxcustoreduzido)
        end

        if maxcustoreduzido <= epsmaxcustoreduzido
            # problema mestre resolvido!

            # captura solução corrente do problema mestre
            x_corrente = value.(x)

            # retorna os padrões utilizados e suas quantidades (possivelmente fracionárias)
            padroes = (x_corrente .> 0)
            return round.(A[:,padroes]), x_corrente[padroes], FOmestre, varadd
        end

        # base do problema mestre não ótima -> adiciona nova coluna
        ncols += 1
        varadd += 1

        # adiciona nova variável ao problema mestre
        xnew = @variable(
            mestre,
            [ncols],
            lower_bound=0.0,
            base_name="x"
        )

        # agrega xnew ao vetor de variáveis originais
        x = [x;xnew[ncols]]

        # coeficiente da nova variável na FO do problema mestre
        set_objective_coefficient(mestre, x[ncols], 1.0)

        # coluna da nova variável na matriz de restrições do problema mestre (solução a do prob auxiliar)
        for i in 1:m
            set_normalized_coefficient(consRef[i], x[ncols], value(a[i]))
        end

        # nova matriz do problema mestre
        A = [A value.(a)]

    end

end


# Função para execução
function executa(arquivo=nothing)
    if arquivo == nothing
        arquivo = "csp.txt"
    end

    @time padroes, quant, FOmestre, varadd = gercol(arquivo, saidas=true)

    if quant != nothing

        println("\n=============================================")
        println("\nFO problema mestre: ", FOmestre, " (", varadd, " colunas adicionadas)")

        if length(padroes[:,1]) <= 10
            println("\nSolução (quantidades possivelmente não inteiras):\n")

            for i in 1:length(quant)
                println("BOBINA ",i,": \t",quant[i],"\t cortes do padrão   ",Vector(padroes[:,i]))
            end
        else
            println("\nQuantidades (possivelmente não inteiras):\n")
            println(quant)
        end


        # SOLUÇÃO INTEIRA
        sol = ceil.(quant.-1e-12)  # menores inteiros maiores que quant[:]

        println("\n=============================================")
        println("\nFO solução inteira aproximada (= número de bobinas utilizadas): ", Int64(sum(sol)))

        if length(padroes[:,1]) <= 10
            println("\nSolução (quantidades inteiras):\n")

            for i in 1:length(sol)
                println("BOBINA ",i,": \t",sol[i],"\t cortes do padrão   ",Vector(padroes[:,i]))
            end
        else
            println("\nQuantidades (inteiras):\n")
            println(sol)
        end

    end
end
