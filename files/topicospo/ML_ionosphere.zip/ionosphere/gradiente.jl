using Printf, LinearAlgebra

struct DADOS
    n::Int64                # dimensão do dado
    m::Int64                # quant de dados
    z::Matrix{Float64}      # matrix dos dados
    y::Vector{Float64}      # vetor de rótulos (1 ou -1)
end

# função objetivo
function obj(x, sigma, p::DADOS)
    return 0.5*sigma*x'*x + sum( log(1.0 + exp(-p.y[i]*(x'*p.z[i,:]) )) for i in 1:p.n)
end

# gradiente total/parcial da função objetivo. Caso j=0, calcula o gradiente total
function grad!(g, x, sigma, p::DADOS; j=0)
    if j > 0
        g .= 0.0
        g[j] = sigma*x[j]
        # gradiente parcial apenas com a função gj
        h = exp(-p.y[j]*(x'*p.z[j,:]))
        g .-= ((p.y[j]*h)/(1.0 + h)) * p.z[j,:]
    else
        g .= sigma*x
        # gradiente total
        for i in 1:p.n
            h = exp(-p.y[i]*(x'*p.z[i,:]))
            g .-= ((p.y[i]*h)/(1.0 + h)) * p.z[i,:]
        end
    end
    return g
end

# FUNÇÃO PRINCIPAL
function gradiente(
    p::DADOS;
    sigma=1e-6,
    x0=nothing,
    t=0.5,          # tamanho do passo
    maxiter=10000,
    saidas=true,
    metodo=:estocastico,
    hist=true       # retorna histórico de f e ∇f (grad total)
)
    iter   = 0
    status = 1

    if x0 == nothing
        # define ponto inicial caso não fornecido
        x = zeros(Float64,p.n)
    else
        x = deepcopy(x0)
    end

    # vetor gradiente
    g = similar(x)

    gsupn = Inf
    f = Inf
    histf = Float64[]
    histg = Float64[]

    if hist
        f  = obj(x, sigma, p)
        grad!(g, x, sigma, p)
        gsupn = norm(g,Inf)
        push!(histf, f)
        push!(histg, gsupn)
    end

    # imprimi cabeçalho saídas
    if saidas && hist
        @printf("\nit     \tf         |g pj|\n==========================")
        @printf("\n%d\t%8.2e  %8.2e", iter, f, gsupn)
    end

    while (iter < maxiter)

        # direção
        if metodo == :incremental
            # incremental cíclico
            k = mod(iter, p.n) + 1
            grad!(g, x, sigma, p, j=k)

        elseif metodo == :classico
            # gradiente total (método usual)
            grad!(g, x, sigma, p)

        else
            # estocástico
            k = Int64(floor(p.n*rand())) + 1
            grad!(g, x, sigma, p, j=k)
        end

        # passo (t constante)
        x = x - t*g

        # compute total gradient only for analysis purposes
        if hist
            # evaluate total cost and gradient
            f = obj(x, sigma, p)
            grad!(g, x, sigma, p)

            gsupn = norm(g, Inf)

            push!(histf, f)
            push!(histg, gsupn)
        end

        iter += 1

        # imprimi iteração corrente
        if saidas && hist
            if mod(iter,20) == 0
                @printf("\n\nit     \tf         |g|\n==========================")
            end
            @printf("\n%d\t%8.2e  %8.2e", iter, f, gsupn)
        end

    end

    return histf, histg
end
