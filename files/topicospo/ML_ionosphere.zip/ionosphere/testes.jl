###################################################
# Executa teste GRADIENTE INCREMENTAL vs ESTOCÁTICO
#
# Autor: Leonardo D. Secchin
# Data : 08/06/2026
###################################################

using Plots, DelimitedFiles, Format

include("gradiente.jl")

# formato impressão ponto flutuante
fmt = generate_formatter("%.6lf")

# carrega dados de banco Ionosphere
data = readdlm("ionosphere.data",',')
z = Float64.(data[:,1:34])
y = Float64.((data[:,35].=="g")*2 .- 1)
p = DADOS(size(z,2), size(z,1), z, y)

# ponto inicial
x0 = ones(34)

# tamanho do passo
t = 1.5

# número máximo de iterações
maxit = 20000

##############################
println("Executando o método do gradiente incremental...")
f_inc, g_inc = gradiente(p, x0=x0, t=t, maxiter=maxit, saidas=false, metodo=:incremental)

println("Melhor f: $(fmt(minimum(f_inc)))")
println("Melhor |g|: $(fmt(minimum(g_inc)))")
println()
##############################
println("Executando o método do gradiente estocástico...")
f_est, g_est = gradiente(p, x0=x0, t=t, maxiter=maxit, saidas=false, metodo=:estocastico)

println("Melhor f: $(fmt(minimum(f_est)))")
println("Melhor |g|: $(fmt(minimum(g_est)))")
println()
##############################
println("Executando o método do gradiente clássico com passo constante (gradiente total)...")
f_cla, g_cla = gradiente(p, x0=x0, t=t, maxiter=maxit, saidas=false, metodo=:classico)

println("Melhor f: $(fmt(minimum(f_cla)))")
println("Melhor |g|: $(fmt(minimum(g_cla)))")
println()
##############################

# plots
fig_f = plot(title="Ionosphere", xlabel="iterations", ylabel="f", yscale=:log10)
fig_f = plot!(1:length(f_inc), f_inc, label="Incremental")
fig_f = plot!(1:length(f_est), f_est, label="Estocástico")
fig_f = plot!(1:length(f_cla), f_cla, label="Clássico (∇ total)")
savefig(fig_f, "ionosphere_f.pdf")

fig_g = plot(title="Ionosphere", xlabel="iterations", ylabel="gradient sup-norm", yscale=:log10)
fig_g = plot!(1:length(g_inc), g_inc, label="Incremental")
fig_g = plot!(1:length(g_est), g_est, label="Estocástico")
fig_g = plot!(1:length(g_cla), g_cla, label="Clássico (∇ total)")
savefig(fig_g, "ionosphere_g.pdf")

##############################
println("COMPARAÇÃO DE TEMPO:")

println("Gradiente incremental")
@time gradiente(p, x0=x0, t=t, maxiter=maxit, saidas=false, metodo=:incremental, hist=false)

println("Gradiente estocástico")
@time gradiente(p, x0=x0, t=t, maxiter=maxit, saidas=false, metodo=:estocastico, hist=false)

println("Gradiente clássico")
@time gradiente(p, x0=x0, t=t, maxiter=maxit, saidas=false, metodo=:classico, hist=false)

return
