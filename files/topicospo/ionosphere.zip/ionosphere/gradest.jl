using Printf, LinearAlgebra

# FUNÇÃO PRINCIPAL
function gradest(;n=34, m=351, nlp=nothing, x0=nothing, epsopt=1.0e-8, maxiter=1000, saidas=true, options=Dict())

    iter   = 0
    status = 1

    t = (haskey(options,"t")) ? options["t"] : 1e-2

    # define ponto inicial caso não fornecido
    if x0 == nothing
        x0 = zeros(Float64,n)
    end

    x  = float(x0)
    f  = objetivo(x)
    nf = 1

    g = gradiente(x)
    gsupn = norm(g,Inf)

    histf = [f]
    histg = [gsupn]

    fbest = f
    xbest = x

    # imprimi cabeçalho saídas
    if saidas
        @printf("\nit     \tf         |g pj|\n==========================")
        @printf("\n%d\t%8.2e  %8.2e", iter, f, gsupn)
    end

    while (iter < maxiter)

        # cycle
        for j in 1:m
            k = Int64(floor(351*rand())) + 1
            g = gradiente(x, j=k)
            x = x - t*g
        end

        # evaluate total cost
        f = objetivo(x)
        nf += 1

        if f < fbest
            fbest = f
            xbest = x
        end

        iter += 1

        # compute total gradient only for analysis purposes
        gtotal = gradiente(xbest)

        gsupn = norm(gtotal,Inf)

        append!(histf, fbest)
        append!(histg, gsupn)

        # imprimi iteração corrente
        if saidas
            if mod(iter,20) == 0
                @printf("\n\nit     \tf         |g|\n==========================")
            end
            @printf("\n%d\t%8.2e  %8.2e", iter, f, gsupn)
        end

    end

    # compute total gradient only for analysis purposes
    gbest = gradiente(xbest)

    gsupn = norm(gbest,Inf)

    if gsupn <= epsopt
        status = 0
    end

    # saída
    if saidas
        println("\n\n*******************************")
        if status == 0
            println("PROBLEMA RESOLVIDO COM SUCESSO!")
        else
            println("FALHA NA RESOLUÇÃO.")
        end
        println("*******************************\n")
    end

    ng = 0
    return xbest, histf, histg, iter, status, nf, ng
end
