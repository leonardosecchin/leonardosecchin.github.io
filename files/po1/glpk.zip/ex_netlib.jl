using GLPK, JuMP, MatrixDepot

# lista de problemas em https://sparse.tamu.edu/LPnetlib?per_page=All
problema = "lp_afiro"
# problema = "lp_bnl2"
# problema = "lp_dfl001" # GLPK perturba para evitar ciclagem

# Carrega o problema da biblioteca Netlib
P = mdopen("LPnetlib/$(problema)")

# imprime dados na tela
println("Número de variáveis: $(P.n)")
println("Número de restrições: $(P.m)")

# inicia o modelo GLPK
model = Model(GLPK.Optimizer)

# mensagens na tela para fins didáticos
set_attribute(model, "msg_lev", GLPK.GLP_MSG_ALL)

# insere variáveis
@variable(model, x[1:P.n])

# limitantes nas variáveis: P.lo <= x <= P.hi
for i in 1:P.n
    set_lower_bound(x[i], P.lo[i])
    set_upper_bound(x[i], P.hi[i])
end

# na Netlib, os problema são de minimização
# min c'*t
@objective(model, Min, sum(P.c[i]*x[i] for i in 1:P.n))

# as restrições nos modelos na Netlib são todas de igualdade
# Ax = b
@constraint(model, P.A*x == P.b)

# resolve problema
optimize!(model)

if termination_status(model) == OPTIMAL
    println("Função objetivo ótima: $(objective_value(model))")
else
    println("Falha na resolução")
end
