using GLPK, JuMP, MatrixDepot

# lista de problemas em https://sparse.tamu.edu/LPnetlib?per_page=All
problema = "lp_bnl2"

# Carrega o problema da biblioteca Netlib
P = mdopen("LPnetlib/$(problema)")

# imprime dados na tela
println("Problema: $(problema)")
println("Número de variáveis: $(P.n)")
println("Número de restrições: $(P.m)")

# inicia o modelo GLPK
model = Model(GLPK.Optimizer)

# mensagens na tela para fins didáticos
set_attribute(model, "msg_lev", GLPK.GLP_MSG_ALL)

# insere variáveis
@variable(model, x[1:P.n])

# limitantes nas variáveis: P.lo <= x <= P.hi
for i in 1:P.n
    set_lower_bound(x[i], P.lo[i])
    set_upper_bound(x[i], P.hi[i])
end

# na Netlib, os problema são de minimização
# min c'*t
@objective(model, Min, sum(P.c[i]*x[i] for i in 1:P.n))

# as restrições nos modelos na Netlib são todas de igualdade
# Ax = b
@constraint(model, P.A*x == P.b)

# resolve problema
optimize!(model)

println("\n\n",'='^50)
println("MUDANDO CUSTO DE x2 NA FUNÇÃO OBJETIVO")
println('='^50)

println("\n----> Aproveitando base atual...\n")
set_objective_coefficient(model, x[1], -1.0)
optimize!(model)

println("\n----> Reotimizando do zero...\n")
MOIU.reset_optimizer(model)
optimize!(model)


println("\n\n",'='^50)
println("ADICIONANDO UMA RESTRIÇÃO")
println('='^50)

println("\n----> Aproveitando base atual...\n")
@constraint(model, x[1] + x[2] + x[3] + x[4] <= value(x[1])/2)
optimize!(model)

println("\n----> Reotimizando do zero...\n")
MOIU.reset_optimizer(model)
optimize!(model)
