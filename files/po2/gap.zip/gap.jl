###################################################
# Resolução do GAP
# * Requer CPLEX instalado e CPLEX.jl configurado no Julia
# OU
# GLPK instalado
#
# Autor: Leonardo D. Secchin
# Data : 13/10/2026
# leonardosecchin.github.io/po2/
###################################################

# Descrição do GAP:
# https://en.wikipedia.org/wiki/Generalized_assignment_problem

using JuMP, Printf, LinearAlgebra
# using CPLEX
using GLPK

include("readGAP.jl")

#######################
# GAP
#######################
function GAP(m,n,p,w,t; saidas = true)

    ########## modelo GAP ##########
#     GAP = Model(CPLEX.Optimizer)
    GAP = Model(GLPK.Optimizer)

    # saídas do solver na tela (só funciona para CPLEX)
    if !saidas
        set_optimizer_attribute(GAP, "CPXPARAM_ScreenOutput", 0)
    end

    # insere variáveis binárias x[i,j]
    @variable(GAP, x[1:m,1:n], Bin)

    # define função objetivo
    @objective(GAP, Min, sum(p[i,j]*x[i,j] for i in 1:m, j in 1:n))

    # insere restrições de igualdade
    for j in 1:n
        @constraint(GAP, sum(x[i,j] for i in 1:m) == 1)
    end

    # insere restrições de desigualdade
    for i in 1:m
        @constraint(GAP, sum(w[i,j]*x[i,j] for j in 1:n) <= t[i])
    end

    optimize!(GAP)

    return value.(x)
end

function solucao(m, n, p, w, t, x)
    m, n = size(x)
    println("FO ótima: $(sum(p.*x))")

    for i in 1:m
        ocupacao = sum(w[i,:].*x[i,:])
        print("\nBIN $(i)\n$(ocupacao) ocupado, $(t[i] - ocupacao) livre.\nItens:")
        for j in 1:n
            if x[i,j] .> 0.5
                print(" $(j)")
            end
        end
        println()
    end
end

function GAP(problema; saidas = true)
    m, n, p, w, t = readGAP(problema)
    println('='^30)
    println("Dados do problema:")
    println("Número de bins (m): $(m)")
    println("Número de items (n): $(n)")
    println('='^30)
    println()

    x = GAP(m, n, p, w, t, saidas = saidas)

    solucao(m, n, p, w, t, x)
end
