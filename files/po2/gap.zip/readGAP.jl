###################################################
# Função que lê instâncias do GAP
#
# Autor: Leonardo D. Secchin
# Data : 22/08/2023
###################################################

using DelimitedFiles

# FORMATO:
#
# number of agents (m), number of jobs (n)
#  for each agent i (i=1,...,m) in turn:
#      cost of allocating job j to agent i (j=1,...,n)
#  for each agent i (i=1,...,m) in turn:
#      resource consumed in allocating job j to agent i (j=1,...,n)
#  resource capacity of agent i (i=1,...,m)
#
# Fonte: https://www-or.amp.i.kyoto-u.ac.jp/members/yagiura/gap/

"""
Lê instância do GAP no diretório `GAP_instances`.

Uso:

`m,n,p,w,t = GAPinstance("[NOME ARQUIVO]")`
"""
function readGAP(arquivo)

    dados = readdlm("GAP_instances/"*arquivo)

    # número de agentes
    m = dados[1,1]

    # número de trabalhos
    n = dados[1,2]

    colunas = size(dados,2)
    linhas = ceil(Int,n/colunas)

    # custos c[i,j]
    p = zeros(Int, m, n)

    for i = 1:m
        for j = 1:n
            # busca posição do j-ésimo trabalho no i-ésimo bloco de dados
            p[i,j] = dados[ ((i-1)*linhas+2):(i*linhas+1) , : ][ floor(Int, (j-1)/colunas)+1 , mod(j-1,colunas)+1 ]
        end
    end

    # consumo
    w = zeros(Int, m, n)

    for i = 1:m
        for j = 1:n
            # busca posição do j-ésimo trabalho no i-ésimo bloco de dados
            w[i,j] = dados[ ((i-1)*linhas+2+linhas*m):(i*linhas+1+linhas*m) , : ][ floor(Int, (j-1)/colunas)+1 , mod(j-1,colunas)+1 ]
        end
    end

    # capacidade de cada agente
    t = zeros(Int, m)
    t = Int.(dados[end,1:m])

    return m, n, p, w, t
end
