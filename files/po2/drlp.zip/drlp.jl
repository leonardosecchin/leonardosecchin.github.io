###################################################
# Double Row problem, modelo de Amaral (2013)
#
# Autor: Leonardo D. Secchin
# Data : 28/08/2023
###################################################

using CPLEX, JuMP, Printf, LinearAlgebra, Printf, DelimitedFiles

function readdrlp(arquivo)
    dados = readdlm("drlp_instances/"*arquivo)

    n = dados[1,1]

    l = dados[2,:]

    c = dados[3:end,:]

    return n, l, c
end


"""
Resolve o problema de layout em fila dupla pelo CPLEX via modelo descrito em

Amaral. Optimal solutions for the double row layout problem. Optim Lett, 7:407-413, 2013.

Uso (requer o CPLEX e interface Julia instalados):

`solvedrlp(arquivo; presolve=[true (padrão)|false], LPrelax=[true|false (padrão)])`

onde

- `arquivo`: nome do arquivo da instância no diretório `drlp_instances`
- `presolve`: ativa/desativa presolve do CPLEX (opcional, padrão `true`)
- `LPrelax`: resolve a relaxação LP? (opcional, padrão `false`)

### Exemplos

- `solvedrlp("singlerow_S9.txt")`
- `solvedrlp("singlerow_S9.txt", LPrelax = true)`
- `solvedrlp("singlerow_S10.txt", presolve = false)`
"""
function solvedrlp(arquivo; output = true, LPrelax = false, presolve = true)

    n, l, c = readdrlp(arquivo)

    if output
        println("==========================================")
        print("Instância: ");println(arquivo)
        print("n = ");println(n)
        println("==========================================")
        println()
    end

    # estrutura JuMP associada com CPLEX
    drlp = direct_model(CPLEX.Optimizer())

    # desliga saídas do CPLEX na tela
    if !output
        set_optimizer_attribute(drlp, "CPXPARAM_ScreenOutput", 0)
    end

    # Desliga presolve?
    #
    # Para a lista de parâmetros, consulte
    # https://www.ibm.com/docs/pt/icos/22.1.0?topic=cplex-list-parameters
    if !presolve
        set_optimizer_attribute(drlp, "CPXPARAM_Preprocessing_Presolve", 0)
    end

    # insere variáveis
    @variable(drlp, x[1:n])
    @variable(drlp, d[i=1:(n-1),j=(i+1):n])
    if LPrelax
        @variable(drlp, 0 <= a[i=1:n,j=union(1:(i-1),(i+1):n)] <= 1)
    else
        @variable(drlp, a[i=1:n,j=union(1:(i-1),(i+1):n)], Bin)
    end

    # limitantes variáveis
    L = sum(l)

    for i = 1:n
        set_lower_bound(x[i], l[i]/2)
        set_upper_bound(x[i], L - l[i]/2)
    end

    # função objetivo
    @objective(drlp, Min, sum(c[i,j]*d[i,j] for i = 1:(n-1), j = (i+1):n))

    # restrições
    for i = 1:(n-1)
        for j = (i+1):n
            @constraint(drlp, d[i,j] >= x[i] - x[j])
            @constraint(drlp, d[i,j] >= x[j] - x[i])

            @constraint(drlp, d[i,j] - a[i,j]*(l[i]+l[j])/2 - a[j,i]*(l[i]+l[j])/2 >= 0)
        end
    end

    for i = 1:n, j = 1:n
        if i != j
            @constraint(drlp, x[i] + (l[i]+l[j])/2 <= x[j] + L*(1 - a[i,j]))
        end
    end

    maxc = maximum(c)
    for i = 1:n
        c[i,i] = maxc + 1
    end

    @constraint(drlp, x[ argmin(c)[1] ] <= x[ argmin(c)[2] ])

    for i = 1:(n-1)
        for j = (i+1):n
            for k = 1:n
                if (k != i) && (k != j)
                    @constraint(drlp, - a[i,j] + a[i,k] + a[j,k] - a[j,i] + a[k,i] + a[k,j] <= 1)
                end
            end
        end
    end

    for i = 1:(n-1)
        for j = (i+1):n
            for k = 1:(j-1)
                if (k != i)
                    @constraint(drlp, - a[i,j] + a[i,k] - a[j,k] + a[j,i] - a[k,i] + a[k,j] <= 1)
                end
            end
        end
    end

    for i = 1:(n-2)
        for j = (i+1):(n-1)
            for k = (j+1):n
                @constraint(drlp, a[i,j] + a[i,k] + a[j,k] + a[j,i] + a[k,i] + a[k,j] >= 1)
            end
        end
    end

    # Resolve drlp
    optimize!(drlp)

    if output
        # FO ótima drlp
        print("FO ótima DRLP: ")
        println(objective_value(drlp))
    end

    return objective_value(drlp)
end
