###################################################
# TESTES
# Este script executa métodos para diferentes problemas.
#
# Autor: Leonardo D. Secchin
# Data : mai 2022
###################################################

using CUTEst, Printf, JuMP, NLPModelsJuMP, NLPModels, Plots
import Contour: contours, levels, level, lines, coordinates

# carrega método do gradiente com busca linear por Armijo + interpolação quadrática + salvaguardas
include("gradiente.jl")

nlp = []


# TESTES COM PROBLEMAS ESPECÍFICOS
function testes()

    P = Model()

    @variable(P, x[1:2])

    @NLobjective(P, Min, x[1]^2 + 10.0*x[2]^2)

    nlp = MathOptNLPModel(P)

    # imprime problema
    println(P)

    # figuras (níveis da função)
    xs = range(-5, stop=5, length=100)
    ys = range(-3, stop=3, length=100)
    f(x,y) = x^2+10*y^2
    fig = contour(xs, ys, f, levels=[5,20,40,60,80], ratio=1, color="gray")

    println("Ponto inicial: (-5,0)")
    x, ~, ~, ~, ~, ~ = gradiente(nlp, x0=[-5.0;0.0], interp=false, salvax=true)

    # figura 1
    fig1 = plot(fig) # niveis
    fig1 = plot!([x[1,:]], [x[2,:]], color="green", mark=:o, markersize=1, label="") # xk
    fig1 = scatter!([x[1,1]], [x[2,1]], color="blue", markersize=4, label="") # pto inicial

    savefig(fig1, "grad_-5.0.svg");

    println()

    println("Ponto inicial: (-5,3)")
    x, ~, ~, ~, ~, ~ = gradiente(nlp, x0=[-5.0;3.0], interp=true, salvax=true)

    # figura 1
    fig2 = plot(fig)
    fig2 = plot!([x[1,:]], [x[2,:]], color="green", mark=:o, markersize=1, label="") # xk
    fig2 = scatter!([x[1,1]], [x[2,1]], color="blue", markersize=4, label="") # pto inicial

    savefig(fig2, "grad_-5.3.svg");

    finalize(nlp)
end


# TESTES COM PROBLEMAS DA CUTEst
function testesCUTEst()

    # máximo de iterações para os métodos
    maxit = 50000

    # abre arquivo de saída em modo inserção
    arq = open("resultados_cutest.txt", "a")

    # seleciona problemas irrestritos com número de variáveis entre 10 e 50
    sif = CUTEst.select(contype="unc", max_var=50, min_var=10, only_free_var=true);

    try

    # Executa o método com 1 iteração no primeiro problema somente para
    # Julia compilar os códigos. Nenhuma saida é tabelada.
    # Assim, o tempo do primeiro problema não é afetado por tempos de
    # compilação.
    nlp = CUTEstModel(sif[1]);
    gradiente(nlp, maxiter=1, saidas=false, interp=false);
    gradiente(nlp, maxiter=1, saidas=false);
    finalize(nlp)

    # escreve cabeçalho no arquivo de saída
    write(arq, "\n\n        Prob |      n | método |    it |         f |     grad | st |       nf | tempo (s)\n"*
                   "=========================================================================================\n")
    flush(arq)

    for i in 1:length(sif)

        println("==============\nCarregando o problema "*sif[i]*"...")

        # carrega problema
        nlp = CUTEstModel(sif[i]);

        # pula problema caso o sentido de otimização não seja "minimização"
        if nlp.meta.minimize == true

            # escreve dados do problema no arquivo de saída
            write(arq, "-------------|--------|--------|-------|-----------|----------|----|----------|----------\n")
            write(arq, @sprintf("%12s | %6d", sif[i], nlp.meta.nvar))
            flush(arq)

            ###############################################
            # APLICA MÉTODO DO GRADIENTE SEM INTERPOLAÇÃO
            ###############################################
            println("Resolvendo "*sif[i]*" pelo método do gradiente s/ interpolação quadrática...")

            # aplica gradiente a partir do ponto inicial fornecido no problema
            tempo = @elapsed ~, f, g, it, nf, st = gradiente(nlp, x0=nlp.meta.x0, maxiter=maxit, saidas=false, interp=false);

            # escreve resultado no arquivo de saida
            write(arq, @sprintf(" |   grad | %5d | %9.2e | %8.2e | %2d | %8d | %4.6f\n",
                    it, f, g, st, nf, tempo))
            flush(arq)

            ###############################################
            # APLICA MÉTODO DO GRADIENTE COM INTERPOLAÇÃO
            ###############################################
            println("Resolvendo "*sif[i]*" pelo método do gradiente c/ interpolação quadrática...")

            # aplica gradiente a partir do ponto inicial fornecido no problema
            tempo = @elapsed ~, f, g, it, nf, st = gradiente(nlp, x0=nlp.meta.x0, maxiter=maxit, saidas=false, interp=true);

            # escreve resultado no arquivo de saida
            write(arq, @sprintf("             |        | g c/iq | %5d | %9.2e | %8.2e | %2d | %8d | %4.6f\n",
                    it, f, g, st, nf, tempo))
            flush(arq)

        end

        # encerra problema atual
        finalize(nlp);

    end

    close(arq);

    # tratamento de erros
    catch err
        close(arq);

        if err isa InterruptException
            println("\nCTRL+C pressionado. Tentando finalizar nlp...");
            finalize(nlp);
        else
            println("============================================\n"*
                    "  Um erro ocorreu :(\n"*
                    "  Isso pode ter sido causado por um CTRL+C acionado no meio do processo.\n"*
                    "  Assim, o problema não foi finalizado, e a estrutura nlp foi perdida.\n"*
                    "  Re-inclua testes.jl e tente novamente. Caso não dê certo, finalize o\n"*
                    "  Julia e recarregue os scripts.\n"*
                    "============================================");
            println("Erro:\n");
            println(err);
            println("\nObs: você pode comentar o bloco try-catch para visualizar a saída completa do erro.")
        end
    end
end
