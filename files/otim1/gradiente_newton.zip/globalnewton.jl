###################################################
# METODO DE NEWTON (PURO E GLOBALIZADO) COMO DESCRITO EM
#
# Autor: Leonardo D. Secchin
# Data : 02/06/2022, atualizado em 28/04/2023
###################################################

using Printf, LinearAlgebra, NLPModels, SparseArrays

include("buscalinear.jl")

# FUNÇÃO PRINCIPAL
"""
`histx, f, gsupn, iter, nf, status = globalnewton(nlp, [opções])`

Métodos de Newton e Newton globalizado com busca linear, como descrito em

`https://leonardosecchin.github.io/files/otim1/4.5.Convergencia_Newton.pdf`

`nlp` é a estrutura `MathOptNLPModel` do problema.

# Saídas

- `x`     : solução encontrada (ou histórico de todos os iterandos gerados)
- `f`     : valor da função objetivo no último iterando
- `gsupn` : norma do infinito do gradiente da função objetivo no último iterando
- `iter`  : número de iterações realizadas
- `nf`    : número de avaliações da função objetivo
- `status`: 0 para sucesso, 1 para falha

# Opções

- `x0`        : ponto inicial (caso não fornecido, `x0 = nlp.meta.x0` ou `x0 = zeros(nlp.meta.nvar)` caso `nlp.meta.x0` não esteja disponível)
- `eps`       : precisão para convergencia (padrão = 1.0e-6)
- `maxiter`   : número máximo de iterações (padrão = 1000)
- `eta`       : parâmetro da condição de Armijo (padrão = 1.0e-4)
- `theta`     : parâmetro da condição do ângulo (padrão = 1.0e-6)
- `beta`      : parâmetro da condição beta (padrão = 1.0e-2)
- `saidas`    : mensagens na tela? (padrão = true)
- `salvax`    : retorna histórico de x (padrão = false)
- `newtonpuro`: executa Newton puro, sem globalização? (padrão = false)

# Exemplos

`julia> using CUTEst`\\
`julia> nlp = CUTEstModel("TRIGON1")`\\
`julia> globalnewton(nlp);`\\
`julia> x, f, gsupn, iter, nf, status = globalnewton(nlp, x0=ones(10), eps=1e-8, newtonpuro=true);`
"""
function globalnewton(nlp; x0=nothing, eps=1.0e-6, maxiter=10000, eta=1e-4, theta=1e-6, beta=1e-2, saidas=true, salvax=false, newtonpuro=false)

    iter   = 0
    status = 1

    # define ponto inicial caso não fornecido
    if x0 == nothing
        # captura ponto inicial da estrutura nlp
        if nlp.meta.x0 != nothing
            x0 = nlp.meta.x0
        else
            # caso não exista, seta x0=origem
            x0 = zeros(Float64,nlp.meta.nvar)
        end
    end

    # f, gradiente e norma
    x     = float(x0)
    f     = obj(nlp, x)
    g     = grad(nlp, x)
    gsupn = norm(g, Inf)

    histx = x

    # contador de avaliações de f
    nf = 1

    # imprimi cabeçalho saídas
    if saidas
        @printf("\nit     \tf         |grad|    t         Newton?\n=============================================")
        @printf("\n%d\t%8.2e  %8.2e  %8.2e        %d", iter, f, gsupn, Inf, false)
    end

    while gsupn > eps && iter < maxiter

        # Direção
        d = []

        # direção de Newton foi usada?
        newton = true

        try
            # Direção de Newton

            # Calcula a Hessiana em x
            H = hess(nlp, x)

            # resolve Hd = -g com fatoração interna do Julia (embutida no comando \ ao usar "Symmetric")
            d = (Symmetric(sparse(H)))\(-g)

            if !newtonpuro
                # normas euclideanas de d e g
                deucn = norm(d, 2)
                geucn = norm(g, 2)

                # verifica a condição do ângulo e se d != 0
                if (dot(g,d) > -theta*geucn*deucn) || (deucn == 0.0)
                    # condição não satisfeita, prossegue com -grad f
                    d = -g

                    # direção de Newton não satisfaz condição do ângulo
                    newton = false
                else
                    # verifica a condição beta e ajusta d se necessário
                    if deucn < beta*geucn
                        d = (beta*geucn/deucn)*d
                    end
                end
            end
        catch
            # erro no cálculo da direção newtoniana!

            if newtonpuro
                # Newton puro -> retorna erro
                println("\n\nERRO no cálculo da direção newtoniana! Abortando...")
                return histx, f, gsupn, iter, nf, status
            else
                # Newton globalizado -> prossegue com -grad f
                d = -g
                newton = false
            end
        end

        t = []

        if newtonpuro
            # passo de Newton sem busca linear
            x = x + d
            t = 1.0
            f = obj(nlp, x)

            nf += 1
        else
            # Newton globalizado: realiza busca linear

            # retorna novo iterando após busca linear (Armijo + interpolação quadrática)
            x, f, t, lsnf = buscalinear(nlp, x, f, g, d, eta, true)

            nf += lsnf
        end

        # atualiza dados do iterando
        g     = grad(nlp, x)
        gsupn = norm(g, Inf)

        if salvax
            histx = [histx x]
        else
            histx = x
        end

        iter += 1

        # imprime iteração corrente
        if saidas
            if mod(iter,20) == 0
                @printf("\nit     \tf         |grad|    t         Newton?\n=============================================")
            end
            @printf("\n%d\t%8.2e  %8.2e  %8.2e        %d", iter, f, gsupn, t, newton)
        end
    end

    # status de sucesso
    if gsupn <= eps
        status = 0
    end

    # saída
    if saidas
        println("\n\n*******************************")
        if status == 0
            println("PROBLEMA RESOLVIDO COM SUCESSO!")
        else
            println("FALHA NA RESOLUÇÃO.")
        end
        println("*******************************\n")
    end

    return histx, f, gsupn, iter, nf, status
end
