###################################################
# TESTES COM MÉTODOS DO GRADIENTE E NEWTON
#
# Autor: Leonardo D. Secchin
# Data : atualizado 31/03/2026
###################################################

using CUTEst, Printf, JuMP, NLPModelsJuMP, NLPModels, Plots
import Contour: contours, levels, level, lines, coordinates

# carrega métodos
include("gradiente.jl")
include("globalnewton.jl")

nlp = []


# TESTES COM QUADRÁTICA
function testesquad()

    P = Model()

    @variable(P, x[1:2])

    @NLobjective(P, Min, x[1]^2 + 10.0*x[2]^2)

    nlp = MathOptNLPModel(P)

    # imprime problema
    println(P)

    # figuras (níveis da função)
    xs = range(-5, stop=5, length=100)
    ys = range(-3, stop=3, length=100)

    f(x,y) = x^2+10*y^2

    fig = contour(xs, ys, f, levels=[5,20,40,60,80], ratio=1, color="gray")

    println("NEWTON GLOBALIZADO Ponto inicial: (-5,0)")
    x, ~, ~, ~, ~, ~ = globalnewton(nlp, x0=[-5.0;0.0], salvax=true)

    # figura 1
    fig1 = plot(fig) # niveis
    fig1 = plot!([x[1,:]], [x[2,:]], color="green", mark=:o, markersize=1, label="") # xk
    fig1 = scatter!([x[1,1]], [x[2,1]], color="blue", markersize=4, label="") # pto inicial

    savefig(fig1, "figuras/quadratica_newton_-5.0.svg")

    println("\n==============================================\n")

    println("NEWTON GLOBALIZADO Ponto inicial: (-5,3)")
    x, ~, ~, ~, ~, ~ = globalnewton(nlp, x0=[-5.0;3.0], salvax=true)

    # figura 1
    fig2 = plot(fig)
    fig2 = plot!([x[1,:]], [x[2,:]], color="green", mark=:o, markersize=1, label="") # xk
    fig2 = scatter!([x[1,1]], [x[2,1]], color="blue", markersize=4, label="") # pto inicial

    savefig(fig2, "figuras/quadratica_newton_-5.3.svg")

    println("\n==============================================\n")

    println("GRADIENTE SEM INTERPOLAÇÃO Ponto inicial: (-5,0)")
    x, ~, ~, ~, ~, ~ = gradiente(nlp, x0=[-5.0;0.0], interp=false, salvax=true)

    # figura 1
    fig3 = plot(fig)
    fig3 = plot!([x[1,:]], [x[2,:]], color="green", mark=:o, markersize=1, label="") # xk
    fig3 = scatter!([x[1,1]], [x[2,1]], color="blue", markersize=4, label="") # pto inicial

    savefig(fig3, "figuras/quadratica_gradiente_-5.0.svg")

    println("\n==============================================\n")

    println("GRADIENTE SEM INTERPOLAÇÃO Ponto inicial: (-5,3)")
    x, ~, ~, ~, ~, ~ = gradiente(nlp, x0=[-5.0;3.0], interp=false, salvax=true)

    # figura 1
    fig4 = plot(fig)
    fig4 = plot!([x[1,:]], [x[2,:]], color="green", mark=:o, markersize=1, label="") # xk
    fig4 = scatter!([x[1,1]], [x[2,1]], color="blue", markersize=4, label="") # pto inicial

    savefig(fig4, "figuras/quadratica_gradiente_-5.3.svg")

    finalize(nlp)
end


# TESTES COM A FUNÇÃO DE ROSENBROCK
function testesrosenbrock()

    P = Model()

    @variable(P, x[1:2])

    @NLobjective(P, Min, (x[1]-1.0)^2 + 100.0*(x[2] - x[1]^2)^2)

    nlp = MathOptNLPModel(P)

    # imprime problema
    println(P)

    # figuras (níveis da função)
    xs = range(-5, stop=5, length=100)
    ys = range(-3, stop=3, length=100)
    f(x,y) = (x-1.0)^2 + 100.0*(y - x^2)^2
    fig = contour(xs, ys, f, levels=[5,20,40,60,80], ratio=1, color="gray")

    println("GRADIENTE Ponto inicial: (-2,1)")
    x, ~, ~, ~, ~, ~ = gradiente(nlp, x0=[-2.0;1.0], salvax=true)

    # figura 1
    fig1 = plot(fig) # niveis
    fig1 = plot!([x[1,:]], [x[2,:]], color="green", mark=:o, markersize=1, label="") # xk
    fig1 = scatter!([x[1,1]], [x[2,1]], color="blue", markersize=4, label="") # pto inicial

    savefig(fig1, "figuras/rosebrock_gradiente.svg")

    println("\n==============================================\n")

    println("NEWTON Ponto inicial: (-2,1)")
    x, ~, ~, ~, ~, ~ = globalnewton(nlp, x0=[-2.0;1.0], salvax=true)

    # figura 1
    fig2 = plot(fig)
    fig2 = plot!([x[1,:]], [x[2,:]], color="green", mark=:o, markersize=1, label="") # xk
    fig2 = scatter!([x[1,1]], [x[2,1]], color="blue", markersize=4, label="") # pto inicial

    savefig(fig2, "figuras/rosebrock_newton.svg")

    finalize(nlp)
end


# TESTES COM NEWTON PURO E GLOBALIZADO NO EXEMPLO DA AULA ONDE O MÉTODO OSCILA (min f(x) = -cos(x))
function testecos()

    P = Model()

    @variable(P, x)

    @NLobjective(P, Min, -cos(x))

    nlp = MathOptNLPModel(P)

    println("Newton puro iniciando de 1.0")
    globalnewton(nlp, x0=[1.0], newtonpuro=true)

    # tg x0oscila = 2*x0oscila
    x0oscila = 1.1655611852072113
    println("======= X0 solução de tan(x) = 2x: ",x0oscila," =======")

    println("\n==============================================\n")

    println("Newton puro iniciando em X0")

    x, ~, ~, ~, ~, ~ = globalnewton(nlp, x0=[x0oscila], newtonpuro=true, salvax=true)

    println("Sequência gerada:")
    for i in 1:length(x)
        println(x[i])
    end

    println("\n==============================================\n")

    println("Newton puro iniciando em X0 + 10^-15")

    x, ~, ~, ~, ~, ~ = globalnewton(nlp, x0=[x0oscila+1e-15], newtonpuro=true, salvax=true)

    println("Sequência gerada:")
    for i in 1:length(x)
        println(x[i])
    end


    println("\n==============================================\n")

    println("Newton globalizado iniciando de X0")

    x, ~, ~, ~, ~, ~ = globalnewton(nlp, x0=[x0oscila])

    println("Solução: ",x)

    println("\n==============================================\n")

    println("Newton globalizado iniciando de X0 + 10^-15")

    x, ~, ~, ~, ~, ~ = globalnewton(nlp, x0=[x0oscila+1e-15])

    println("Solução: ",x)
end


# TESTES COM PROBLEMAS DA CUTEst
function testesCUTEst()

    # máximo de iterações para os métodos
    maxit = 50000

    # abre arquivo de saída em modo inserção
    arq = open("resultados_cutest.txt", "a")

    # seleciona problemas irrestritos com número de variáveis no intervalo [min_var,max_var]
#     sif = CUTEst.select_sif_problems(contype="unc", max_var=50, min_var=10, only_free_var=true)
    # problemas irrestritos selecionados
    sif = [
        "LUKSAN13LS"
        "SPIN2LS"
        "TOINTGOR"
        "CHNRSNBM"
        "LUKSAN12LS"
        "LUKSAN21LS"
        "MANCINO"
        "LUKSAN22LS"
        "BA-L1SPLS"
        "SENSORS"
        "LUKSAN11LS"
        "LUKSAN16LS"
        "ERRINRSM"
        "QING"
        "HYDC20LS"
        "ERRINROS"
        "LUKSAN14LS"
        "LUKSAN15LS"
        "BA-L1LS"
        "CHNROSNB"
        "TOINTPSP"
        "TOINTQOR"
        "VARDIM"
        "GENROSE"
        "OSCIPATH"
        "PENALTY1"
        "INTEQNELS"
    ]
    sort!(sif)

    # por garantia, busca entre problemas baixados de dentro do Julia
    set_mastsif()

    # Executa o método com 1 iteração no primeiro problema somente para
    # Julia compilar os códigos. Nenhuma saida é tabelada.
    # Assim, o tempo do primeiro problema não é afetado por tempos de
    # compilação.
    nlp = CUTEstModel(sif[1])
    gradiente(nlp, maxiter=1, saidas=false, interp=false)
    gradiente(nlp, maxiter=1, saidas=false)
    globalnewton(nlp, maxiter=1, saidas=false)
    finalize(nlp)

    # escreve cabeçalho no arquivo de saída
    write(arq, "\n\n        Prob |      n | método |    it |         f |     grad | st |       nf | tempo (s)\n"*
                   "=========================================================================================\n")
    flush(arq)

    for i in 1:length(sif)

        println("==============\nCarregando o problema $(sif[i])...")

        try
        # carrega problema
        nlp = CUTEstModel(sif[i])

        # pula problema caso o sentido de otimização não seja "minimização"
        if nlp.meta.minimize == true

            # escreve dados do problema no arquivo de saída
            write(arq, "-------------|--------|--------|-------|-----------|----------|----|----------|----------\n")
            write(arq, @sprintf("%12s | %6d", sif[i], nlp.meta.nvar))
            flush(arq)

            ###############################################
            # APLICA MÉTODO DO GRADIENTE SEM INTERPOLAÇÃO
            ###############################################
            println("Resolvendo $(sif[i]) pelo método do gradiente s/ interpolação quadrática...")

            # aplica gradiente a partir do ponto inicial fornecido no problema
            tempo = @elapsed ~, f, g, it, nf, st = gradiente(nlp, x0=nlp.meta.x0, maxiter=maxit, saidas=false, interp=false)

            # escreve resultado no arquivo de saida
            write(arq, @sprintf(" |   grad | %5d | %9.2e | %8.2e | %2d | %8d | %4.6f\n",
                    it, f, g, st, nf, tempo))
            flush(arq)

            ###############################################
            # APLICA MÉTODO DO GRADIENTE COM INTERPOLAÇÃO
            ###############################################
            println("Resolvendo $(sif[i]) pelo método do gradiente c/ interpolação quadrática...")

            # aplica gradiente a partir do ponto inicial fornecido no problema
            tempo = @elapsed ~, f, g, it, nf, st = gradiente(nlp, x0=nlp.meta.x0, maxiter=maxit, saidas=false, interp=true)

            # escreve resultado no arquivo de saida
            write(arq, @sprintf("             |        | g c/iq | %5d | %9.2e | %8.2e | %2d | %8d | %4.6f\n",
                    it, f, g, st, nf, tempo))
            flush(arq)

            ###############################################
            # APLICA NEWTON GLOBALIZADO
            ###############################################
            println("Resolvendo $(sif[i]) por Newton globalizado...")

            # aplica gradiente a partir do ponto inicial fornecido no problema
            tempo = @elapsed ~, f, g, it, nf, st = globalnewton(nlp, x0=nlp.meta.x0, maxiter=maxit, saidas=false)

            # escreve resultado no arquivo de saida
            write(arq, @sprintf("             |        | newton | %5d | %9.2e | %8.2e | %2d | %8d | %4.6f\n",
                    it, f, g, st, nf, tempo))
            flush(arq)

        end
        # tratamento de erros
        catch err
            finalize(nlp)
        end

        # encerra problema atual
        finalize(nlp)
    end

    close(arq)
end
