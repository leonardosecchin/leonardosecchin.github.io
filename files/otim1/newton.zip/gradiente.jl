###################################################
# METODO DO GRADIENTE COM BUSCA LINEAR ARMIJO + INTERPOLAÇÃO QUADRÁTICA + SALVAGUARDAS
#
# Autor: Leonardo D. Secchin
# Data : 25/05/2022
#
# Exemplos de uso:
#   gradiente(nlp);
#   gradiente(nlp, x0=[1;1]);
#   gradiente(nlp, eps=1e-8);
#   x, f, gsupn, iter, nf, status = gradiente(nlp, x0=[1;1], eps=1e-8, maxiter=2000, saidas=true);
# onde 'nlp' é a estrutura MathOptNLPModel do problema.
###################################################

using Printf, LinearAlgebra, NLPModels

# FUNÇÃO PRINCIPAL
function gradiente(nlp; x0=nothing, eps=1.0e-6, maxiter=10000, saidas=true, interp=true, salvax=false)

    # DADOS DE ENTRADA
    # nlp     : estrutura MathOptNLPModel do problema
    # x0      : ponto inicial (opcional)
    # eps     : precisão para convergencia (opcional, padrão=1.0e-6)
    # maxiter : número máximo de iterações (opcional, padrão=1000)
    # saidas  : mensagens na tela? (opcional, padrão=SIM)
    # interp  : usa interpolação quadrática? (opcional, padrão=SIM)
    # salvax  : guarda histórico de x (opcional, padrão=NÃO)

    # DADOS DE SAÍDA
    # x       : último iterando
    # f       : f(x)
    # gsupn   : norma do supremo do gradiente de f
    # iter    : número de iterações
    # status  : 0=sucesso, 1=falha

    iter   = 0
    status = 1

    # parâmetro busca linear inexata (Armijo)
    eta = 1e-4

    # define ponto inicial caso não fornecido
    if x0 == nothing
        # captura ponto inicial da estrutura nlp
        if nlp.meta.x0 != nothing
            x0 = nlp.meta.x0
        else
            # caso não exista, seta x0=origem
            x0 = zeros(Float64,nlp.meta.nvar)
        end
    end

    # f, gradiente e norma
    x     = float(x0)
    f     = obj(nlp, x)
    g     = grad(nlp, x)
    gsupn = norm(g, Inf)

    histx = x

    # contador de avaliações de f
    nf = 1

    # imprimi cabeçalho saídas
    if saidas
        @printf("\nit     \tf         |grad|\n==========================")
        @printf("\n%d\t%8.2e  %8.2e", iter, f, gsupn)
    end

    while gsupn > eps && iter < maxiter
        # direção
        d = -g

        # retorna novo iterando após busca linear (Armijo + interpolação quadrática)
        x, f, lsnf = buscalinear(nlp, x, f, g, d, eta, interp)

        nf += lsnf

        # atualiza dados do iterando
        g     = grad(nlp, x)
        gsupn = norm(g, Inf)

        if salvax
            histx = [histx x]
        else
            histx = x
        end

        iter += 1

        # imprimi iteração corrente
        if saidas
            if mod(iter,20) == 0
                @printf("\n\nit     \tf         |grad|\n==========================")
            end
            @printf("\n%d\t%8.2e  %8.2e", iter, f, gsupn)
        end
    end

    # status de sucesso
    if gsupn <= eps
        status = 0
    end

    # saída
    if saidas
        println("\n\n*******************************")
        if status == 0
            println("PROBLEMA RESOLVIDO COM SUCESSO!")
        else
            println("FALHA NA RESOLUÇÃO.")
        end
        println("*******************************\n")
    end

    return histx, f, gsupn, iter, nf, status
end


# BUSCA LINEAR COM INTERPOLAÇÃO QUADRÁTICA E SALVAGUARDAS

function buscalinear(nlp, x, f, g, d, eta, interp)

    # calcula g' * d
    gtd = g' * d

    # passo inicial
    t = 1.0

    # primeira tentativa
    xnew = x + d
    fnew = obj(nlp, xnew)

    # contador de avaliações de f
    lsnf = 1

    # enquanto Armijo não é satisfeito, atualiza t...
    while fnew > f + t*eta*gtd

        if interp
            # passo da interpolação quadrática
            tquad = - 0.5*gtd*(t^2) / (fnew - f - t*gtd)

            # salvaguardas
            if (tquad < 0.1*t) || (tquad > 0.9*t)
                # backtracking
                t = t / 2.0
            else
                # aceita o passo da interpolação quadrática
                t = tquad
            end
        else
            t = t / 2.0
        end

        # novo ponto
        xnew = x + t*d
        fnew = obj(nlp, xnew)

        lsnf += 1
    end

    # retorna novo iterando
    return xnew, fnew, lsnf
end
