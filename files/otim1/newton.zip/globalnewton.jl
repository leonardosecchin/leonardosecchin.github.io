###################################################
# METODO DE NEWTON (PURO E GLOBALIZADO) COMO DESCRITO EM
# https://leonardosecchin.github.io/files/otim1/4.2.Metodo_de_Newton.pdf
#
# Autor: Leonardo D. Secchin
# Data : 02/06/2022, atualizado em 26/04/2023
###################################################

using Printf, LinearAlgebra, NLPModels, SparseArrays

# FUNÇÃO PRINCIPAL
function globalnewton(nlp; x0=nothing, eps=1.0e-6, maxiter=10000, eta=1e-4, theta=1e-6, beta=1e-2, saidas=true, salvax=false, newtonpuro=false)

    # DADOS DE ENTRADA
    # nlp     : estrutura MathOptNLPModel do problema
    # x0      : ponto inicial (opcional)
    # eps     : precisão para convergencia (opcional, padrão=1.0e-6)
    # maxiter : número máximo de iterações (opcional, padrão=1000)
    # eta     : parâmetro busca linear inexata (Armijo) (opcional, padrão=1.0e-4)
    # saidas  : mensagens na tela? (opcional, padrão=SIM)
    # salvax  : guarda histórico de x (opcional, padrão=NÃO)
    # newtonpuro : executa Newton puro (sem globalização) (opcional, padrão=NÃO)

    # DADOS DE SAÍDA
    # x       : último iterando
    # f       : f(x)
    # gsupn   : norma do supremo do gradiente de f
    # iter    : número de iterações
    # status  : 0=sucesso, 1=falha

    iter   = 0
    status = 1

    # define ponto inicial caso não fornecido
    if x0 == nothing
        # captura ponto inicial da estrutura nlp
        if nlp.meta.x0 != nothing
            x0 = nlp.meta.x0
        else
            # caso não exista, seta x0=origem
            x0 = zeros(Float64,nlp.meta.nvar)
        end
    end

    # f, gradiente e norma
    x     = float(x0)
    f     = obj(nlp, x)
    g     = grad(nlp, x)
    gsupn = norm(g, Inf)

    histx = x

    # contador de avaliações de f
    nf = 1

    # imprimi cabeçalho saídas
    if saidas
        @printf("\nit     \tf         |grad|    t         Newton?\n=============================================")
        @printf("\n%d\t%8.2e  %8.2e  %8.2e        %d", iter, f, gsupn, Inf, false)
    end

    while gsupn > eps && iter < maxiter

        # Direção
        d = []

        # direção de Newton foi usada?
        newton = true

        try
            # Direção de Newton

            # Calcula a Hessiana em x
            H = hess(nlp, x)

            # resolve Hd = -g com fatoração interna do Julia (embutida no comando \ ao usar "Symmetric")
            d = (Symmetric(sparse(H)))\(-g)

            if !newtonpuro
                # normas euclideanas de d e g
                deucn = norm(d, 2)
                geucn = norm(g, 2)

                # verifica a condição do ângulo e se d != 0
                if (dot(g,d) > -theta*geucn*deucn) || (deucn == 0.0)
                    # condição não satisfeita, prossegue com -grad f
                    d = -g

                    # direção de Newton não satisfaz condição do ângulo
                    newton = false
                else
                    # verifica a condição beta e ajusta d se necessário
                    if deucn < beta*geucn
                        d = (beta*geucn/deucn)*d
                    end
                end
            end
        catch
            # erro no cálculo da direção newtoniana!

            if newtonpuro
                # Newton puro -> retorna erro
                println("\n\nERRO no cálculo da direção newtoniana! Abortando...")
                return histx, f, gsupn, iter, nf, status
            else
                # Newton globalizado -> prossegue com -grad f
                d = -g
                newton = false
            end
        end

        t = []

        if newtonpuro
            # passo de Newton sem busca linear
            x = x + d
            t = 1.0
            f = obj(nlp, x)

            nf += 1
        else
            # Newton globalizado: realiza busca linear

            # retorna novo iterando após busca linear (Armijo + interpolação quadrática)
            x, f, t, lsnf = buscalinear(nlp, x, f, g, d, eta)

            nf += lsnf
        end

        # atualiza dados do iterando
        g     = grad(nlp, x)
        gsupn = norm(g, Inf)

        if salvax
            histx = [histx x]
        else
            histx = x
        end

        iter += 1

        # imprime iteração corrente
        if saidas
            if mod(iter,20) == 0
                @printf("\nit     \tf         |grad|    t         Newton?\n=============================================")
            end
            @printf("\n%d\t%8.2e  %8.2e  %8.2e        %d", iter, f, gsupn, t, newton)
        end
    end

    # status de sucesso
    if gsupn <= eps
        status = 0
    end

    # saída
    if saidas
        println("\n\n*******************************")
        if status == 0
            println("PROBLEMA RESOLVIDO COM SUCESSO!")
        else
            println("FALHA NA RESOLUÇÃO.")
        end
        println("*******************************\n")
    end

    return histx, f, gsupn, iter, nf, status
end


# BUSCA LINEAR COM INTERPOLAÇÃO QUADRÁTICA E SALVAGUARDAS

function buscalinear(nlp, x, f, g, d, eta)

    # calcula g' * d
    gtd = g' * d

    # passo inicial
    t = 1.0

    # primeira tentativa
    xnew = x + d
    fnew = obj(nlp, xnew)

    # contador de avaliações de f
    lsnf = 1

    # enquanto Armijo não é satisfeito, atualiza t...
    while fnew > f + t*eta*gtd

        # passo da interpolação quadrática
        tquad = - 0.5*gtd*(t^2) / (fnew - f - t*gtd)

        # salvaguardas
        if (tquad < 0.1*t) || (tquad > 0.9*t)
            # backtracking
            t = t / 2.0
        else
            # aceita o passo da interpolação quadrática
            t = tquad
        end

        # novo ponto
        xnew = x + t*d
        fnew = obj(nlp, xnew)

        lsnf += 1
    end

    # retorna novo iterando
    return xnew, fnew, t, lsnf
end
